# Ads Made Simple
