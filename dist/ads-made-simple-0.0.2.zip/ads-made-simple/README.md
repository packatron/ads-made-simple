# Ads Made Simple


## Release

```bash
docker-compose build release && docker-compose run --rm release
```